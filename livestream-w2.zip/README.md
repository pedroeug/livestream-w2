# Livestream W2

Plataforma de dublagem em tempo real para Twitch.

## Como usar

1. Copie este repositório para sua máquina ou nuvem.
2. Preencha o arquivo `.env` com suas chaves de API.
3. Execute `docker-compose up --build`.
4. Acesse `http://localhost:8000` e insira o nome do canal da Twitch.
5. Clique em "Assistir com Dublagem" e aguarde cerca de 30 segundos para iniciar a dublagem.